﻿using Microsoft.EntityFrameworkCore;
using Session2.Configurations;
using Session2.Contents;
using Session2.Models.Category;

namespace Session2.Contexts
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> Context) : base(Context) { 
        
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new ProductEntityConfiguration());
            modelBuilder.ApplyConfiguration(new CategoryEntityConfiguration());
            modelBuilder.Entity<GetAllCategoryDto>(builder => { 
                builder.HasNoKey();
                builder.ToTable("GetAllCategoryDto");
                });
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}
