﻿using Session2.Contents;
using Session2.Repositories;

namespace Session2.Services
{
    public class ProductService: IProductService
    {
        readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public Product GetProduct(int id)
        {
            Product product = _productRepository.GetProductById(id);
            return product;
        }

        public List<Product> GetProducts()
        {
            return _productRepository.GetAllProducts();
        }

    }
}
