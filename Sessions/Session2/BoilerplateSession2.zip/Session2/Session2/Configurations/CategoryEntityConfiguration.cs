﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Session2.Contents;

namespace Session2.Configurations
{
    public class CategoryEntityConfiguration : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.HasData(
                new Category
                {
                    CategoryId = 1,
                    CategoryName = "LMN",
                    CategoryDescription = "decwec",

                },
                new Category
                {
                    CategoryId = 2,
                    CategoryName = "XYZ",
                    CategoryDescription = "wedwdwexa asa",

                });
        }
    }
}
