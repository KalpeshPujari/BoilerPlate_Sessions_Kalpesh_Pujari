﻿
using AutoMapper;
using Session2.Contents;
using Session2.Models.Category;
using Session2.Models.Product;

namespace Session2.Configurations
{
    public class MapperConfig : Profile
    {
        public MapperConfig()
        {
            CreateMap<Category, GetAllCategoryDto>().ReverseMap();
            CreateMap<Product, GetAllProductDto>().ReverseMap();
        }
    }
}
