﻿using Microsoft.EntityFrameworkCore;
using ProductAppServer.Configuration;
using ProductAppServer.Content;

namespace ProductAppServer.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> Context) : base(Context) { 
        

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new ProductEntityConfiguration());
            modelBuilder.ApplyConfiguration(new CategoryEntityConfiguration());
        }
        public DbSet<Product>  Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        
    }
}
