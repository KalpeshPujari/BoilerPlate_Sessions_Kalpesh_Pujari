﻿using ProductAppServer.Content;

namespace ProductServerAPI.Model
{
    public class GetProductDetailsDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public double ProductPrice { get; set; }

        public string ProductImg { get; set; }

    }
}
