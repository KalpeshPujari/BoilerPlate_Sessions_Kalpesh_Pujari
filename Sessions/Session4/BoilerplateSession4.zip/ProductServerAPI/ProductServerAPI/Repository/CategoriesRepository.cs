﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductAppServer.Content;
using ProductAppServer.Context;
using System;
using System.Diagnostics.Metrics;

namespace ProductServerAPI.Repository
{
    public class CategoriesRepository : ICategoriesRepository
    {
        readonly private AppDbContext _appDbContext;

        public CategoriesRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
            
        }
        public async Task<List<Category>> GetAllCategories()
        {
            return await _appDbContext.Categories.ToListAsync();
        }

        public async Task<Category> GetCategoryById(int id)
        {
            return await _appDbContext.Categories.Include(q => q.Products).FirstOrDefaultAsync(a => a.CategoryId == id);
            
        }
        public void AddCategory(Category category)
        {
            _appDbContext.Categories.Add(category);
            _appDbContext.SaveChanges();
        }


        public async Task<ActionResult<Category>> UpdateCategory(Category category)
        {
            var result = await _appDbContext.Categories
                .FirstOrDefaultAsync(e => e.CategoryId == category.CategoryId);

            if (result != null)
            {
                result.CategoryName = category.CategoryName;
                result.CategoryDescription = category.CategoryDescription;
                
                await _appDbContext.SaveChangesAsync();

                return result;
            }

            return null;
        }


        public async Task<ActionResult<Category>> DeleteCategory(int id)
        {
            var result = await _appDbContext.Categories
                .FirstOrDefaultAsync(e => e.CategoryId == id);
            if (result != null)
            {
                _appDbContext.Categories.Remove(result);
                await _appDbContext.SaveChangesAsync();
                return result;
            }

            return null;
        } 

    }
}
