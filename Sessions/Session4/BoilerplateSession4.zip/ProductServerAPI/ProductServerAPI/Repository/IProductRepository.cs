﻿using Microsoft.AspNetCore.Mvc;
using ProductAppServer.Content;

namespace ProductServerAPI.Repository
{
    public interface IProductRepository
    {
        void AddProduct(Product product);
        Task<List<Product>> GetAllProducts();
        Task<Product> GetProductById(int id);
        Task<ActionResult<Product>> DeleteProduct(int id);
    }
}
