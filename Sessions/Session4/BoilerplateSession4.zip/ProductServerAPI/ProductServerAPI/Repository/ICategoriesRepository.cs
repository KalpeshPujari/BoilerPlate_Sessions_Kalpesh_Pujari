﻿using Microsoft.AspNetCore.Mvc;
using ProductAppServer.Content;

namespace ProductServerAPI.Repository
{
    public interface ICategoriesRepository
    {
        void AddCategory(Category category);
        Task<ActionResult<Category>> DeleteCategory(int id);
        Task<List<Category>> GetAllCategories();
        Task<Category> GetCategoryById(int id);
        Task<ActionResult<Category>> UpdateCategory(Category category);
    }
}
