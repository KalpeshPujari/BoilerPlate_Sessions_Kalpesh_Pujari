﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductAppServer.Content;
using ProductAppServer.Context;

namespace ProductServerAPI.Repository
{

    public class ProductRepository : IProductRepository
        {
            readonly private AppDbContext _appDbContext;

            public ProductRepository(AppDbContext appDbContext)
            {
                _appDbContext = appDbContext;

            }

        public void AddProduct(Product product)
        {
            _appDbContext.Products.Add(product);
            _appDbContext.SaveChanges();
        }

        public async Task<List<Product>> GetAllProducts()
            {
                return await _appDbContext.Products.ToListAsync();
            }

        public async Task<Product> GetProductById(int id)
        {
            return await _appDbContext.Products.Include(q => q.Category).FirstOrDefaultAsync(a => a.ProductId == id);

        }
        public async Task<ActionResult<Product>> DeleteProduct(int id)
        {
            var result = await _appDbContext.Products
                .FirstOrDefaultAsync(e => e.ProductId == id);
            if (result != null)
            {
                _appDbContext.Products.Remove(result);
                await _appDbContext.SaveChangesAsync();
                return result;
            }

            return null;
        }

    }




}
