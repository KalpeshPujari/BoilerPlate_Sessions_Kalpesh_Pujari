﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ProductAppServer.Content;

namespace ProductAppServer.Configuration
{
    public class ProductEntityConfiguration : IEntityTypeConfiguration<Product>
    {
        public void Configure(EntityTypeBuilder<Product> builder)
        {
            builder.HasData(
                new Product
                {
                    ProductId = 1,
                    ProductName = "Moto G52",
                    ProductDescription = "It comes with 4GB, 6GB of RAM. " +
                    "The Motorola Moto G52 runs Android 12 and is powered by a 5000mAh battery. ",
                    ProductImg = "https://shorturl.at/kxIV2",
                    ProductPrice = 14999.0,
                    CategoryId = 1

                },
                new Product
                {
                    ProductId = 2,
                    ProductName = "OnePlus LED Smart Android TV 32Y1 (Black)",
                    ProductDescription = "Resolution: HD Ready (1366x768) | Refresh Rate: 60 hertz " +
                    "Connectivity: 2 HDMI ports to connect set top box, Blu Ray players," +
                    "gaming console | 2 USB ports to connect hard drives and other USB devices",
                    ProductImg = "https://shorturl.at/fvHK3",
                    ProductPrice = 39999.0,
                    CategoryId = 2
                });
        }

    }
}
